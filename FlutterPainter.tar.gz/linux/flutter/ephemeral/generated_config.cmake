# Generated code do not commit.
file(TO_CMAKE_PATH "/home/sirodevs/Developer/Flutter/Sdk/default" FLUTTER_ROOT)
file(TO_CMAKE_PATH "/home/sirodevs/Developer/Flutter/Projects/FlutterPainter" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.2" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 2 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 0 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=/home/sirodevs/Developer/Flutter/Sdk/default"
  "PROJECT_DIR=/home/sirodevs/Developer/Flutter/Projects/FlutterPainter"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4y,RkxVVFRFUl9WRVJTSU9OPTMuNDcuOQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049YzE5N2NhNTE5OQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ODljMzllZGZkZg==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy43"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=/home/sirodevs/Developer/Flutter/Projects/FlutterPainter/.dart_tool/package_config.json"
  "FLUTTER_TARGET=/home/sirodevs/Developer/Flutter/Projects/FlutterPainter/lib/main.dart"
)
